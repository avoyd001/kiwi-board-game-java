public class Player {

    private static int nextId = 0;

    private int id;

    private Boolean isComputer;

    private GameLevel level;

    private int location = 0;

    public Player() {
        id = ++nextId;
    }

    public Player(Boolean isComputer) {
        this();
        this.isComputer = isComputer;
    }

    public Player(Boolean isComputer,GameLevel level) {
        this();
        this.level = level;
        this.isComputer = isComputer;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Boolean getComputer() {
        if(isComputer!=null)
            return isComputer;
        else
            return false;
    }

    public void setComputer(Boolean computer) {
        isComputer = computer;
    }

    public static int getNextId() {
        return nextId;
    }

    public static void setNextId(int nextId) {
        Player.nextId = nextId;
    }

    public GameLevel getLevel() {
        return level;
    }

    public void setLevel(GameLevel level) {
        this.level = level;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }

    @Override
    public boolean equals(Object obj) {
        Player player2 = (Player) obj;
        return player2.getId()==getId();
    }
}
