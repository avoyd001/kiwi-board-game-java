public class KiviGame {

    public static void main(String[] args)
    {
        Game game = new Game();

    }
}
