import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Game {

    private JFrame jFrame;
    private JPanel welcomePanel;
    private JPanel gamePanel;
    private Dimension len = Toolkit.getDefaultToolkit().getScreenSize();
    private int numOfPlayers = 2;
    private java.util.List<Player> players;
    private JLabel gameStatus;
    private JButton rollDiceButton;
    private JLabel diceResultsLabel;
    private GameBoard gameBoard;
    private Random random = new Random();

    Game() {
        jFrame = new JFrame("Kivi Game");
        players = new ArrayList<>();
        jFrame.setLocation((int) (len.width * 0.125), (int) (len.height * 0.125));
        jFrame.setSize((int) (len.width * 0.75), (int) (len.height * 0.75));
        jFrame.setVisible(true);

        welcomePanel = new JPanel();
        welcomePanel.setSize((int) (len.width * 0.75), (int) (len.height * 0.75));
        jFrame.setContentPane(welcomePanel);

        showWelcomeScreen();
    }

    private void showWelcomeScreen() {
        welcomePanel.setBackground(new Color(165, 87, 232));
        welcomePanel.setLayout(null);

        JLabel heading = new JLabel("Welcome to Kivi Game", JLabel.CENTER);
        heading.setLocation(0, welcomePanel.getHeight() / 4);
        heading.setSize(welcomePanel.getWidth(), 30);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("Arial", Font.BOLD, 20));

        welcomePanel.add(heading);

        JButton chooseSettingsBtn = new JButton("Choose Player Settings");
        chooseSettingsBtn.setBounds(welcomePanel.getWidth() / 2 - 125, welcomePanel.getHeight() / 2, 250, 40);
        chooseSettingsBtn.addActionListener(e -> showPlayerSettingsDialog());

        welcomePanel.add(chooseSettingsBtn);
        welcomePanel.revalidate();
        welcomePanel.repaint();
    }

    private void showPlayerSettingsDialog() {
        JPanel settingsPanel = new JPanel();
        settingsPanel.setLayout(new GridLayout(10, 1));

        String[] playerOptions = {"2", "3", "4"};
        JComboBox<String> numPlayersBox = new JComboBox<>(playerOptions);

        JCheckBox isComputer2 = new JCheckBox("Player 2 is Computer");
        JCheckBox isComputer3 = new JCheckBox("Player 3 is Computer");
        JCheckBox isComputer4 = new JCheckBox("Player 4 is Computer");

        JCheckBox[] computerChecks = {isComputer2, isComputer3, isComputer4};

        GameLevel[] levels = GameLevel.values();
        String[] difficultyLevels = new String[levels.length];
        for (int i = 0; i < levels.length; i++) {
            difficultyLevels[i] = levels[i].name();
}

        JComboBox<String> difficultyBox = new JComboBox<>(difficultyLevels);

        settingsPanel.add(new JLabel("Select number of players:"));
        settingsPanel.add(numPlayersBox);
        settingsPanel.add(new JLabel("Select computer players:"));
        settingsPanel.add(new JLabel());
        settingsPanel.add(isComputer2);
        settingsPanel.add(new JLabel());
        settingsPanel.add(isComputer3);
        settingsPanel.add(new JLabel());
        settingsPanel.add(isComputer4);
        settingsPanel.add(new JLabel());
        settingsPanel.add(new JLabel("Select difficulty for computer players:"));
        settingsPanel.add(difficultyBox);

        int result = JOptionPane.showConfirmDialog(jFrame, settingsPanel, "Player Settings", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            numOfPlayers = Integer.parseInt((String) numPlayersBox.getSelectedItem());
            players.clear();
            for (int i = 0; i < numOfPlayers; i++) {
                boolean isComputer = computerChecks[i].isSelected();
                String difficulty = (String) difficultyBox.getSelectedItem();
                if (isComputer)
                    players.add(new Player(isComputer, GameLevel.valueOf(difficulty)));
                else
                    players.add(new Player(isComputer));
            }
            setupGameBoard();
        }
    }

    private void setupGameBoard() {
        gamePanel = new JPanel();
        gamePanel.setLayout(new BorderLayout());
        gamePanel.setBackground(Color.WHITE);

        gameStatus = new JLabel("Player 1's Turn : ", JLabel.CENTER);
        gameStatus.setForeground(Color.blue);
        gameStatus.setFont(new Font("Arial", Font.BOLD, 25));

        gamePanel.add(gameStatus, BorderLayout.NORTH);

        this.gameBoard = new GameBoard(this);
        JPanel tmpBoard = new JPanel();
        tmpBoard.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
        tmpBoard.setBackground(Color.WHITE);
        tmpBoard.add(gameBoard);

        gamePanel.add(tmpBoard, BorderLayout.CENTER);

        JPanel dicePanel = new JPanel();
        dicePanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        diceResultsLabel = new JLabel("Dice Results: ", JLabel.CENTER);
        diceResultsLabel.setFont(new Font("Arial", Font.BOLD, 20));
        dicePanel.add(diceResultsLabel);

        rollDiceButton = new JButton("Roll All Dice");
        rollDiceButton.setForeground(Color.WHITE);
        rollDiceButton.setBackground(Color.BLUE);
        rollDiceButton.addActionListener(e -> rollAllDice());
        dicePanel.add(rollDiceButton);

        gamePanel.add(dicePanel, BorderLayout.SOUTH);

        int estWidth = jFrame.getWidth();
        int estHeight = jFrame.getHeight() - dicePanel.getPreferredSize().height - gameStatus.getPreferredSize().height - 50;

        int prefBoardSize = Math.min(estHeight, estWidth);
        gameBoard.setPreferredSize(new Dimension(prefBoardSize, prefBoardSize));
        gameBoard.setSize(new Dimension(prefBoardSize, prefBoardSize));
        tmpBoard.repaint();
        gameBoard.repaint();

        gamePanel.revalidate();
        gamePanel.repaint();
        jFrame.setContentPane(gamePanel);
        jFrame.revalidate();
        jFrame.repaint();

        startGame();
    }

    private int playerTurn = 0;

    private void startGame() {
        gameBoard.setBoardConfiguration(new Player[49]);

        for (int i = 0; i < numOfPlayers; i++)
            players.get(i).setLocation(0);

        gameBoard.setCellText(0, "Start");
        gameBoard.setCellText(48, "Finish");
        gameBoard.setCellText(5, "Lose Turn");
        gameBoard.setCellText(12, "Go Again");

        gameBoard.getBoardConfiguration()[0] = players.get(0);

        Runnable showGameStatus = () -> {
            gameStatus.setText(String.format("Player %d Turn ", playerTurn + 1));
            gameStatus.repaint();

            rollDiceButton.setEnabled(!players.get(playerTurn).getComputer());
        };

        showGameStatus.run();
    }

    private void rollAllDice() {
        int[] diceRolls = new int[6];
        for (int i = 0; i < diceRolls.length; i++) {
            diceRolls[i] = random.nextInt(6) + 1;
        }

        String results = "Dice Results: ";
        for (int i = 0; i < diceRolls.length; i++) {
            results += "Dice " + (i + 1) + ": " + diceRolls[i] + " ";
        }

        diceResultsLabel.setText(results);
        diceResultsLabel.repaint();

        playerTurn++;
        playerTurn = playerTurn % numOfPlayers;
        gameStatus.setText(String.format("Player %d Turn ", playerTurn + 1));
        gameStatus.repaint();

        rollDiceButton.setEnabled(!players.get(playerTurn).getComputer());
    }
}