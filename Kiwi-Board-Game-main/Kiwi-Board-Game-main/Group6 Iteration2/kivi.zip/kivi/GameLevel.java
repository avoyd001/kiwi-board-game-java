public enum GameLevel {
    Easy,
    Hard
}
