import javax.swing.*;
import java.awt.*;

public class GameBoard extends JPanel {
    private Game game;
    private final int rows = 7, cols = 7;
    private Player[] boardConfiguration = new Player[49]; 
    private String[] cellTexts = new String[49]; 

    public GameBoard(Game game) {
        this.game = game;
        setPreferredSize(new Dimension(500, 500));


        cellTexts[0] = "AA\nBB";
        cellTexts[1] = "ABCDE";
        cellTexts[2] = "sum <= 12";
        cellTexts[3] = "AAA";
        cellTexts[4] = "all odd";
        cellTexts[5] = "all even";
        cellTexts[6] = "AAA";
        cellTexts[7] = "all even";
        cellTexts[8] = "AAAA\nBB";
        cellTexts[9] = "AAA"    ;
        cellTexts[10] = "AA\nBB\nCC";
        cellTexts[11] = "ABCD";
        cellTexts[12] = "AAA\nBBB";
        cellTexts[13] = "sum >= 30";  
        cellTexts[14] = "ABCD"    ;
        cellTexts[15] = "AAAA"  ;
        cellTexts[16] = "sum >= 30";  
        cellTexts[17] = "ABCDE";
        cellTexts[18] = "AAAA\nBB";
        cellTexts[19] = "all odd";
        cellTexts[20] = "AAA\nBB";
        cellTexts[21] = "sum <= 12";
        cellTexts[22] = "AAA\nBB";
        cellTexts[23] = "all even";
        cellTexts[24] = "AAA\nBBB";
        cellTexts[25] = "sum <= 12";  
        cellTexts[26] = "AA\nBB";
        cellTexts[27] = "ABCDE";
        cellTexts[28] = "AAA";
        cellTexts[29] = "ABCDE";
        cellTexts[30] = "AA\nBB\nCC";
        cellTexts[31] = "all odd";
        cellTexts[32] = "ABCD";
        cellTexts[33] = "sum >= 30"; 
        cellTexts[34] = "AA\nBB";
        cellTexts[35] = "all odd";
        cellTexts[36] = "AAA\nBBB";
        cellTexts[37] = "ABCDE";
        cellTexts[38] = "AAAA\nBB";
        cellTexts[39] = "AAA\nBB";
        cellTexts[40] = "AA\nBB\nCC";
        cellTexts[41] = "sum <= 12" ;
        cellTexts[42] = "ABCD";
        cellTexts[43] = "sum >= 30";
        cellTexts[44] = "AAAA";
        cellTexts[45] = "AA\nBB";
        cellTexts[46] = "all odd";
        cellTexts[47] = "AAAA";
        cellTexts[48] = "AAA\nBB";

    }

    public Player[] getBoardConfiguration() {
        return boardConfiguration;
    }

    public void setBoardConfiguration(Player[] boardConfiguration) {
        if (boardConfiguration.length == this.boardConfiguration.length) {
            this.boardConfiguration = boardConfiguration;
            repaint(); 
        }
    }

    public void setCellText(int index, String text) {
        if (index >= 0 && index < cellTexts.length) {
            cellTexts[index] = text;
            repaint();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBoardGrid(g);
        drawCellTexts(g);
        drawPlayers(g);
    }

    private void drawBoardGrid(Graphics g) {
        int cellSize = getWidth() / cols;
        g.setColor(Color.BLACK);

        for (int i = 0; i <= rows; i++) {
            g.drawLine(0, i * cellSize, getWidth(), i * cellSize);
        }
        for (int j = 0; j <= cols; j++) {
            g.drawLine(j * cellSize, 0, j * cellSize, getHeight());
        }
    }

    private void drawCellTexts(Graphics g) {
    int cellSize = getWidth() / cols;
    g.setFont(new Font("Arial", Font.PLAIN, cellSize / 6));
    g.setColor(Color.BLACK);

    for (int i = 0; i < cellTexts.length; i++) {
        int row = i / cols;
        int col = i % cols;
        int x = col * cellSize;
        int y = row * cellSize;

        // Split text into lines (using '\n' or a space-based split)
        String[] lines = cellTexts[i].split("\n"); // Support manual new lines

        int lineHeight = g.getFontMetrics().getHeight(); // Space between lines
        int startY = y + (cellSize / 2) - (lines.length * lineHeight) / 2; // Center vertically

        for (String line : lines) {
            int textX = x + cellSize / 2 - g.getFontMetrics().stringWidth(line) / 2;
            g.drawString(line, textX, startY);
            startY += lineHeight; // Move down for the next line
        }
    }
}


    private void drawPlayers(Graphics g) {
        int cellSize = getWidth() / cols;
        g.setFont(new Font("Arial", Font.BOLD, cellSize / 2));

        for (int i = 0; i < boardConfiguration.length; i++) {
            Player player = boardConfiguration[i];
            if (player == null) continue;   

            int row = i / cols;
            int col = i % cols;
            int x = col * cellSize;
            int y = row * cellSize;

            g.setColor(Color.RED);
            g.fillOval(x + cellSize / 4, y + cellSize / 4, cellSize / 2, cellSize / 2);

            g.setColor(Color.WHITE);
            String playerNum = String.valueOf(player.getId());
            int textX = x + cellSize / 2 - g.getFontMetrics().stringWidth(playerNum) / 2;
            int textY = y + cellSize / 2 + g.getFontMetrics().getAscent() / 2;
            g.drawString(playerNum, textX, textY);
        }
    }
}
