import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class KiviGameGUI extends JFrame {
    private KiviGame game;
    private JPanel boardPanel;
    private JLabel statusLabel;
    private JTextArea diceArea;
    private JButton nextTurnButton;
    private JMenuItem saveMenuItem;

    // 2D array for board buttons (7x7)
    private JButton[][] boardButtons = new JButton[7][7];

    // Two different fonts:
    private static final Font LABEL_FONT = new Font("Arial", Font.BOLD, 18);  // For board labels
    private static final Font STONE_FONT = new Font("Arial", Font.BOLD, 54); // For the stone symbols

    // Game turn state
    private int currentRound = 1;
    private int currentPlayerIndex = 0;
    private int[] currentDice;
    private boolean waitingForMove = false;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LauncherFrame(); // Show the vibrant launcher screen
        });
    }

    public KiviGameGUI(KiviGame game) {
        this.game = game;
        setTitle("Kivi Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(220, 220, 250)); // Light lavender
        add(mainPanel, BorderLayout.CENTER);

        // Board panel
        boardPanel = new JPanel(new GridLayout(7, 7, 2, 2));
        boardPanel.setBackground(new Color(200, 200, 240));
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                JButton btn = new JButton(game.board.squares[i][j].label);
                btn.setFocusPainted(false);
                btn.setFont(LABEL_FONT);
                btn.setBackground(Color.WHITE);

                final int row = i, col = j;
                btn.addActionListener(e -> {
                    // Only allow clicks if it's a human turn
                    if (waitingForMove && isValidMove(row, col)) {
                        Player currentPlayer = game.players.get(currentPlayerIndex);
                        // Place the stone
                        game.board.placeStone(row, col, currentPlayer);

                        // Show the player's symbol in black
                        btn.setText(currentPlayer.stoneSymbol);
                        btn.setForeground(Color.BLACK);
                        btn.setFont(STONE_FONT);
                        btn.setBackground(Color.LIGHT_GRAY);

                        waitingForMove = false;
                        statusLabel.setText("Move accepted. Next turn...");
                        advanceTurn();
                    }
                });
                boardButtons[i][j] = btn;
                boardPanel.add(btn);
            }
        }
        mainPanel.add(boardPanel, BorderLayout.CENTER);

        // Control panel
        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.setBackground(new Color(220, 220, 250));

        statusLabel = new JLabel("Welcome to Kivi Game GUI");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        controlPanel.add(statusLabel, BorderLayout.NORTH);

        diceArea = new JTextArea(2, 20);
        diceArea.setEditable(false);
        diceArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        controlPanel.add(new JScrollPane(diceArea), BorderLayout.CENTER);

        nextTurnButton = new JButton("Next Turn");
        nextTurnButton.setFont(new Font("Arial", Font.BOLD, 14));
        nextTurnButton.setBackground(new Color(170, 200, 255));
        nextTurnButton.addActionListener(e -> nextTurn());
        controlPanel.add(nextTurnButton, BorderLayout.SOUTH);

        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        // Menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        saveMenuItem = new JMenuItem("Save Game");
        saveMenuItem.addActionListener(e -> saveGameDialog());
        fileMenu.add(saveMenuItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        updateBoardButtons();
        updateStatus();
    }

    /**
     * Returns a list of valid moves (row,col) based on the current dice.
     * We no longer highlight them on the GUI.
     */
    private java.util.List<int[]> getValidMoves() {
        java.util.List<int[]> valid = new java.util.ArrayList<>();
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                Square sq = game.board.squares[i][j];
                if (sq.isEmpty() && CombinationChecker.checkCombo(sq.combo, currentDice)) {
                    valid.add(new int[]{i, j});
                }
            }
        }
        return valid;
    }

    private boolean isValidMove(int row, int col) {
        java.util.List<int[]> valid = getValidMoves();
        for (int[] move : valid) {
            if (move[0] == row && move[1] == col) {
                return true;
            }
        }
        return false;
    }

    private void nextTurn() {
        if (currentRound > 10) {
            showFinalScores();
            return;
        }
        Player currentPlayer = game.players.get(currentPlayerIndex);
        statusLabel.setText("Round " + currentRound + " - " + currentPlayer.name + "'s turn");
        if (currentPlayer.isComputer) {
            processComputerTurn(currentPlayer);
        } else {
            processHumanTurn(currentPlayer);
        }
    }

    private void showFinalScores() {
        int highScore = -1;
        String winner = "";
        StringBuilder msg = new StringBuilder("<html>Final Scores:<br/>");
        for (Player p : game.players) {
            int s = game.board.scoreForPlayer(p);
            msg.append(p.name).append(": ").append(s).append("<br/>");
            if (s > highScore) {
                highScore = s;
                winner = p.name;
            }
        }
        msg.append("<br/><b>Winner: ").append(winner).append(" with ").append(highScore).append(" points!</b></html>");
        JOptionPane.showMessageDialog(this, msg.toString(), "Game Over", JOptionPane.INFORMATION_MESSAGE);
        nextTurnButton.setEnabled(false);
    }

    // Computer turn
    private void processComputerTurn(Player p) {
        currentDice = rollDice();
        String diceStr = "Computer roll: " + Arrays.toString(currentDice);
        if (p.difficulty.equalsIgnoreCase("Hard")) {
            int currentScore = getMaxValidSquareBaseScore(currentDice);
            int[] newDice = rollDice();
            int newScore = getMaxValidSquareBaseScore(newDice);
            if (newScore > currentScore) {
                currentDice = newDice;
                diceStr += "\n(Hard) rethrow: " + Arrays.toString(currentDice);
            }
        }
        diceArea.setText(diceStr);

        if (CombinationChecker.isSixOfAKind(currentDice)) {
            java.util.List<int[]> choices = new java.util.ArrayList<>();
            for (int i = 0; i < 7; i++) {
                for (int j = 0; j < 7; j++) {
                    choices.add(new int[]{i, j});
                }
            }
            int[] choice = choices.get(new Random().nextInt(choices.size()));
            game.board.forcePlaceStone(choice[0], choice[1], p);

            JButton btn = boardButtons[choice[0]][choice[1]];
            btn.setText(p.stoneSymbol);
            btn.setForeground(Color.BLACK);
            btn.setFont(STONE_FONT);
            btn.setBackground(Color.LIGHT_GRAY);

            JOptionPane.showMessageDialog(this, p.name + " (Computer) placed stone at (Row " + (choice[0] + 1) +
                    ", Col " + (choice[1] + 1) + ")");
        } else if (CombinationChecker.isFiveOfAKind(currentDice) ||
                   CombinationChecker.isStraightOfSix(currentDice)) {
            java.util.List<int[]> free = game.board.getAllFreeSquares();
            if (!free.isEmpty()) {
                int[] choice = free.get(new Random().nextInt(free.size()));
                game.board.placeStone(choice[0], choice[1], p);

                JButton btn = boardButtons[choice[0]][choice[1]];
                btn.setText(p.stoneSymbol);
                btn.setForeground(Color.BLACK);
                btn.setFont(STONE_FONT);
                btn.setBackground(Color.LIGHT_GRAY);

                JOptionPane.showMessageDialog(this, p.name + " (Computer) placed stone at (Row " + (choice[0] + 1) +
                        ", Col " + (choice[1] + 1) + ")");
            } else {
                JOptionPane.showMessageDialog(this, p.name + " (Computer) has no free squares. Stone returned.");
            }
        } else {
            java.util.List<int[]> valid = getValidMoves();
            if (valid.isEmpty()) {
                JOptionPane.showMessageDialog(this, p.name + " (Computer) has no valid moves. Stone returned.");
            } else {
                int[] choice = valid.get(new Random().nextInt(valid.size()));
                game.board.placeStone(choice[0], choice[1], p);

                JButton btn = boardButtons[choice[0]][choice[1]];
                btn.setText(p.stoneSymbol);
                btn.setForeground(Color.BLACK);
                btn.setFont(STONE_FONT);
                btn.setBackground(Color.LIGHT_GRAY);

                JOptionPane.showMessageDialog(this, p.name + " (Computer) placed stone at (Row " + (choice[0] + 1) +
                        ", Col " + (choice[1] + 1) + ")");
            }
        }
        p.stonesLeft--;
        advanceTurn();
    }

    // Human turn
    private void processHumanTurn(Player p) {
        currentDice = rollDice();
        String diceStr = "Your roll: " + Arrays.toString(currentDice);
        int rethrows = 0;
        while (rethrows < 2) {
            int option = JOptionPane.showConfirmDialog(this, diceStr + "\nRethrow any dice?",
                    "Rethrow?", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                String input = JOptionPane.showInputDialog(this,
                        "Enter dice indices (1-6) to rethrow, separated by spaces (or blank for none):");
                if (input != null && !input.trim().isEmpty()) {
                    currentDice = rethrowDice(currentDice, input);
                    diceStr = "After rethrow: " + Arrays.toString(currentDice);
                    rethrows++;
                } else {
                    break;
                }
            } else {
                break;
            }
        }
        diceArea.setText(diceStr);

        // For special combos
        if (CombinationChecker.isSixOfAKind(currentDice)) {
            JOptionPane.showMessageDialog(this,
                    "Special: Six-of-a-Kind! You may place on ANY square (override).");
            waitingForMove = true;
        } else if (CombinationChecker.isFiveOfAKind(currentDice) ||
                   CombinationChecker.isStraightOfSix(currentDice)) {
            JOptionPane.showMessageDialog(this,
                    "Special: Five-of-a-Kind or Straight-of-6! Place on any free square.");
            waitingForMove = true;
        } else {
            java.util.List<int[]> valid = getValidMoves();
            if (valid.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No valid square. Stone returned to box.");
            } else {
                waitingForMove = true;
                JOptionPane.showMessageDialog(this, "Choose a valid square for your stone.");
            }
        }
    }

    private int[] rollDice() {
        int[] dice = new int[6];
        Random r = new Random();
        for (int i = 0; i < 6; i++) {
            dice[i] = r.nextInt(6) + 1;
        }
        return dice;
    }

    private int[] rethrowDice(int[] dice, String input) {
        String[] parts = input.split("\\s+");
        Random r = new Random();
        for (String part : parts) {
            try {
                int idx = Integer.parseInt(part) - 1;
                if (idx >= 0 && idx < 6) {
                    dice[idx] = r.nextInt(6) + 1;
                }
            } catch (Exception ex) {
                // ignore invalid input
            }
        }
        return dice;
    }

    private int getMaxValidSquareBaseScore(int[] dice) {
        int maxScore = 0;
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                Square sq = game.board.squares[i][j];
                if (sq.isEmpty() && CombinationChecker.checkCombo(sq.combo, dice)) {
                    maxScore = Math.max(maxScore, sq.baseScore);
                }
            }
        }
        return maxScore;
    }

    private void advanceTurn() {
        currentPlayerIndex++;
        if (currentPlayerIndex >= game.players.size()) {
            currentPlayerIndex = 0;
            currentRound++;
        }
        if (currentRound > 10) {
            showFinalScores();
            return;
        }
        diceArea.setText("");
        updateBoardButtons();
        updateStatus();
    }

    // Update the board display, setting squares for either a placed stone or label.
    private void updateBoardButtons() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                Square sq = game.board.squares[i][j];
                JButton btn = boardButtons[i][j];
                if (!sq.isEmpty()) {
                    btn.setText(sq.owner.stoneSymbol);
                    btn.setForeground(Color.BLACK);
                    btn.setFont(STONE_FONT);
                    btn.setBackground(Color.LIGHT_GRAY);
                } else {
                    btn.setText(sq.label);
                    btn.setForeground(Color.BLACK);
                    btn.setFont(LABEL_FONT);
                    btn.setBackground(Color.WHITE);
                }
            }
        }
    }

    private void updateStatus() {
        statusLabel.setText("Round " + currentRound + " - Next turn ready.");
    }

    private void saveGameDialog() {
        JFileChooser chooser = new JFileChooser(".");
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            String filename = chooser.getSelectedFile().getAbsolutePath();
            game.saveGame(filename);
            JOptionPane.showMessageDialog(this, "Game saved to " + filename);
        }
    }
}
